# PR52 corrected implementation transfer

Base: `cbe1795ad5d678a25d594e61eb607ef2656be4a0`. This is a delta, not a main-branch snapshot.

1. Download/extract this package outside the target checkout. Verify SHA256SUMS.
2. In the existing PR52 branch checkout, inspect its current HEAD and working-tree changes.
3. Run `git apply --check /absolute/path/pr52-corrected-since-cbe1795.patch`. If it fails, STOP and reconcile conflicts individually. Do not reset, force, overwrite newer main files, or apply with ignored rejects.
4. Once the check passes, apply `git apply /absolute/path/pr52-corrected-since-cbe1795.patch`. Review the diff and publish through your authenticated GitHub workflow to the existing PR branch. Do not replace main with this archive.
5. Run required Xcode26.3 validation on the actual new public SHA. Existing 82-pass simulator result does not waive that gate.

`source/` contains exact changed-file bytes only, for review and hash comparison; it is NOT an overwrite installer. `handoff.json` contains original and corrected per-file SHA-256 checksums. The patch includes validation evidence at its original repository paths.

SQL284 is already deployed. Preserve the migration file for source parity, but do not blindly run it again. Exact-definition guards intentionally reject drift.

SQL282/283 and other unchanged PR52 files already exist at the base revision and therefore require no delta. Android, unrelated main changes, managed configuration, credentials, signing material and Rork history are excluded.

The Swift/XCTest async teardown workaround, frozen review inputs, retained first-tank evidence, amendment durable request/version/UUID, full lost-response receipt verification, and overlapping-operation guards are included. Direct legacy cleanup integration, live authenticated acceptance, original-iPhone repair and final public-SHA CI remain open exactly as recorded. No tests or builds were rerun for this export.
